from typing import List

wordfile = open("words.txt", "r")
wordlist = wordfile.read()

WORDS = []
ALPHABET = []
TOTAL_WORDS = 0

GREEN_POINTS = 2
YELLOW_POINTS = 1

letter_scores = {}
word_scores = {}


def score_letter(letter: str, words: List) -> float:
    score = 0
    for word in words:
        for i in range (0,5):
            if word[i] = letter:
                score = score + 1

    return (score/TOTAL_WORDS)



def main():
    for line in wordlist.split("\n"):
        if len(line) == 5:
            WORDS.append(line.upper())
            TOTAL_WORDS = TOTAL_WORDS + 1

    counter = "A"
    while ord(counter) <= ord("Z"):
        ALPHABET.append(counter)
        counter = chr(ord(counter) + 1)

    for letter in ALPHABET:
        letter_scores[letter] = score(letter, WORDS)

    print(letter_scores)


if __name__ == "__main__":
    main()
    input("Press enter to close: ")
